# Exercice dirigé: Border radius

## Couleurs du second cercle
* #ff00d7
* #ff8bf6
* purple
* #d16bff